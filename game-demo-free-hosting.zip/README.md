# Static Demo Website

This package is a safe static-demo structure suitable for GitHub Pages, Cloudflare Pages, or Netlify.

## Deploy
Upload the contents of this folder to your chosen static host. The entry file is `index.html`.

No server-side PHP, authentication, payment processing, or credential collection is included.
